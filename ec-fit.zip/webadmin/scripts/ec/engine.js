/*
 ===================== Q U E S T I O N   E N G I N E =====================
 
 Generic engine for displaying a series of questions and evaluating rules.
 It's generic! It is used by the Eligibility Calculator (EC), but nothing
 in the engine directory should contain any code that is specific to EC 
 (or any other implementation).
 
 
 ------ General functionality ------
 
 Questionnaires consist of a series of questions divided into groups. At any
 time the user is answering the questions in a particular group, which is
 highlighted. Groups should typically contain only a few questions.
 
 Questions and groups (and in fact any other elements) can be conditional - they're
 only displayed if an earlier question or questions were answered in a certain
 way.
 
 The implementation defines a set of rules - these are defined in terms of answers to
 questions, and other rules. At the end of the questionnaire, the implementation 
 evaluates the rules and determines the results to display to the user.
 
 
 ------ Getting started ------
 
 Use the EC code as a guideline. The general structure is:
 
 - calculator/index.html: 
        Content, marked up with certain "magic" classes and custom attributes 
        (see below). Don't put any Javascript in here.
 - calculator/rules.js: 
        Rule definitions, using our expression syntax (see below).
 - calculator/calculator.js:
        EC-specific code.
 
 
  ------ The HTML ------

 HTML authors are free to structure their HTML however they want to - the
 engine does not require the use of specific HTML elements. The only
 structure required is that questions are inside groups.

 The HTML is then marked up with classes and custom attributes that are meaningful
 to the engine (see below).
 
 The main caveat is that value attributes for checkboxes and radio buttons need
 to be chosen so that they work with expressions (see expressions section below).
 
 
 Classes:
 
 - class="group":
        a question group - contains a number of questions
        
 - class="question":
        a question - typically contains some text followed by an input of some kind
 
 
 
 Attributes (these are prefixed with "data-" so that they're valid html5):
 
 - data-visible: 
        eg. data-visible="$age >= 18 && $age < 65"
        The element is only displayed if the condition is met. Typically used for
        questions that only display under certain circumstances (eg. superannuation)
 
 - data-ineligible (on questions only):
        If this condition is met, go straight to displaying the results, skipping
        all remaining questions.
        Typically used when an answer makes the user ineligible and you don't
        want to waste their time answering the rest of the questions.
 
 - data-required-checkbox-group:
        Makes it compulsory to tick at least one checkbox in a group of them. Put
        it in an element surrounding the group (checkbox group, not question group!).
 

 ------ Validation ------
 
 All questions are compulsory and you can't move to the next group until everything has
 been answered. The exception to this is checkboxes, but you can use the
 data-required-checkbox-group attribute (above) to make checkbox answers required.
 
 (Could enhance the engine to allow optional questions in future.)
 
 We use JQuery Validation for text fields, which works by adding data-type classes to the
 input element, eg:
 
 - class="number" - numeric
 - class="currency" - dollars and cents (custom type defined here)
 - class="nzdate" - date (custom type defined here)
 - many other types built into JQuery Validation - see the docs
 
 Further constraints are specified using attributes, eg:
 - min="16": minimum value
 - min="65": maximum value
 - again, see the docs for more
 (Note that unfortunately these custom attributes aren't html5-compliant.)
 
 To override the built-in error message(s) for a field, we have a custom attribute,
 like this:
        data-error="Please enter something more sensible"
 
 
 
 ------ Expressions ------
 
 eg: "$gender == 'Female' && $workingAge"

 Expressions are used 
    - as values for certain custom attributes (see above) such as visibility, and
    - for rule definitions 
 
 They're like JavaScript expressions (in fact we use eval()), with the addition of
 the $ syntax. $something evaluates to:
    - the result of the rule called "something", or
    - the answer entered for the input (text field, radio button, etc) named "something"
 
 Be careful not to create circular dependencies in your rule definitions!
 
 
 To make this work smoothly, we do data type conversion when evaluating answers:
 
    - Text fields with class "number" or "currency" are converted to numbers. This makes
      comparison work, eg. "$dependentChildren > 2"
    
    - Radio buttons and checkboxes are converted to booleans if their values are "true"
      or "false". 
      Thus you can use boolean expressions, eg. "$partner", rather than "$partner == 'true'". 
      (In fact, checkboxes should always be booleans.)
      
    - Unanswered questions evaluate to undefined
    
    - Everything else is a string
    
 */
var engine;
var debugConditions = true;

$(document).ready(function () {
    engine.onReady();
});

engine = {
    
    // =============== E X T E R N A L   C O N F I G U R A T I O N ===========
    
    /** 
     * When the last question in a group is answered, go to the next question automatically. 
     * Convenient, but potentially confusing for users.
     * Set this from the client if desired.
     */
    autoNext:false,

    /**
     * When the current group changes it is scrolled into view, this far (in pixels)
     * from the top of the window. The client should adjust this if necessary, eg. if
     * (like EC) it has a fixed header at the top of the window.
     */
    groupScrollYPosition: 20,


    /** Files containing rules. Override this in the client. */
    rulesFiles: [],


    /**
     * Called when they reach the end of the questions. The client should override this!
     */
    onFinished: function(ineligible) {},

    /**
     * Called after clearing all inputs within an element, usually because the element
     * (eg. a question or group) is being hidden.
     * 
     * The client can override if they have additional custom tasks to do.
     */
    onControlsClearedInElement: function(elt) {},
    

    // =========== E X T E R N A L   C O N F I G U R A T I O N   E N D S ===========

    validator:undefined,
    currentGroupNum:0,
    SLIDE_TIME:500,
    definitions: {},
    
    parseRules: function(content, destinationMap) {
        if (destinationMap == undefined)
            destinationMap = {};
            
        content = content.replace(/\/\/.*?$/gm, ""); // remove line comments
        content = content.replace(/[\n\r]/gm, ""); // remove line breaks
        content = content.replace(/\/\*.*?\*\//g, ""); // remove block comments
        
        var p;
        while ((p = content.indexOf(":")) >= 0) {
            var name = $.trim(content.substring(0, p));
            debug(name);
            content = $.trim(content.substring(p + 1));
            
            // The value is a map of conditions to values. Treat this specially.
            if (content.match(/^\{/)) {
                debug("it's a map!");
                var mapName = name + "_evalMap";
                destinationMap[name] = "engine.evalMap(engine.definitions[\"" + mapName + "\"])";
                
                // Get everything up to the closing }
                p = content.indexOf("}");
                if (p < 0)
                    throw "missing } in " + content;
                
                var mapContent = content.substring(1, p);
                content = $.trim(content.substring(p + 1));
                destinationMap[mapName] = engine.parseRules(mapContent);

                // consume the ;
                if (!content.match(/^;/))
                    throw "missing ; in " + content;
                content = content.substring(1);
                debug("finished map");
            }
            
            // The value is an expression (the normal case)
            else {
                p = content.indexOf(";");
                if (p < 0)
                    throw "missing ; in " + content;
                destinationMap[name] = $.trim(content.substring(0, p));

                content = content.substring(p + 1);
            }
        }
        
        // We'll have consumed everything unless there's a syntax error in the file.
        if (!content.match(/^\s*$/))
            throw "invalid syntax in rules file; leftover content: " + content;
        
        return destinationMap;
    },
    
    onReady:function () {
        if (engine.rulesFiles.length > 0) {
            var rulesFile = engine.rulesFiles.pop();
            debug("loading rules file: " + rulesFile);
            $.get(rulesFile, undefined, function(content) {
                engine.parseRules(content, engine.definitions);
                engine.onReady();
            }, "text");
            return;
        }


        debug("====== hello ======");

        // Make sure everything's hidden to start off with. The html page should do this in a
        // style block in the head so that content isn't shown while waiting for this JS, but
        // do it here too just in case.
        $(".group, .results").hide();

        // Field validation. Use our own date parsing - validator uses JS's built-in stuff by
        // default, which is (a) too lenient and (b) dependent on the client computer's region settings.
        $.validator.addMethod("nzdate", Date.validateNzDate, "Please enter a valid date");
        $.validator.addMethod("currency", engine.validateCurrency, "Please enter a valid amount");
        
        $.validator.messages["digits"] = "Please enter a whole number";
        
        // Min and max that allow for leading $ and commas
        $.validator.addMethod("min", function(val, elt, param) {
            val = $.trim(val.replace(/^\$/, "").replace(/,/g, ""));
            var result = val == "" || Number(val) >= Number(param);
            return result;
        }, "Please enter a value greater than or equal to {0}");
        
        $.validator.addMethod("max", function(val, elt, param) {
            val = $.trim(val.replace(/^\$/, "").replace(/,/g, ""));
            var result = val == "" || Number(val) <= Number(param);
            return result;
        }, "Please enter a value less than or equal to {0}");
        
        engine.validator = $("form").validate({
            onkeyup: false
        });

        // Expandable help sections
        $(".helpButton").each(function () {
        	
            $(this).click(function () {
                var start = $(this);
                var elt;
                do {
                    elt = start.nextAll(".help").first();
                    start = start.parent();
                }
                while (elt.length == 0);
                //modify text depending on help text status
                if (elt.is(':hidden')){//is currently hidden.
                	$(this).data("helpText",$(this).html());
                	$(this).html('Hide help text');
                	elt.data("wasVisible","true");
                	$(this).data("wasVisible","true");
                }else{
                	$(this).html($(this).data("helpText"));
                	$(this).data("wasVisible","false");
                	elt.data("wasVisible","false");
                }
                elt.slideToggle(engine.SLIDE_TIME);
                return false;
            });
        });
        $(".help").hide();

        // Progress bar - default to 5% (0 looks funny)
        if ($("#progress").length)
            $("#progress").progressbar({value:5});

        
        engine.onDomAdded();

        // Update question visibility every time a question's answered.
        // (We used to update progress here too, but now it's just based on groups so there's no need.)
        $(".question :input").change(function () {
            engine.showOrHideElementsInGroup($(this).closest(".group"));

            // If this is the last question in the group, go to the next group automatically
            // unless this is an input field (which would be confusing).
            if (engine.autoNext) {
                if (
                        $(this).attr("type") != "text" &&
                        $(this).attr("type") != "checkbox" &&
                        $(this).closest(".question").nextAll(".question:visible").length == 0
                        ) {
                    engine.onNext(true);
                }
            }
        });

        engine.changeGroup(0);
    },
    

    /** Add behaviour to the DOM. The client should call this if it adds new elements to the DOM. */
    onDomAdded:function () {
        // make pressing return be the same as clicking next
        $(".question :input").keydown(function (e) {
            if (e.which == 13) {
                if (e.shiftKey) {
                    if (engine.currentGroupNum > 0)
                        engine.onBack();
                }
                else
                    engine.onNext();
                return false;
            }
            else {
                return true;
            }
        });
    }, 
    

    /** They clicked the Back button */
    onBack:function () {
        engine.changeGroup(-1);
        $('#answerAllMessage').hide();
        $('#answerAllMessage').css('visibility','hidden');
        
        //if the section contained help areas that were previously visible, we re-activate them
        
        $('.lastVisibleQuestion > .help').each(function(){     	
        	if ($(this).data("wasVisible")=="true"){
        		$(this).show();
        	}
        	
        });
        
        $('.lastVisibleQuestion > * > .helpButton').each(function(){     	
        	if ($(this).data("wasVisible")=="true"){
        		$(this).data("helpText",$(this).html());
        		$(this).html('Hide help text');
        	}
        	
        });
        
        
    },

    /** They clicked the Next button */
    onNext:function(automatic) {
        var inputSelector = engine.groupSel(engine.currentGroupNum) + " :input:visible";

        // They might have just answered a question in a way that reveals a new question.
        // If so, reveal the new question and don't move to the next group.
        var before = $(inputSelector).length;
        engine.showOrHideElementsInGroup($(engine.groupSel(engine.currentGroupNum)));
        if ($(inputSelector).length > before)
            return;

        // Make sure everything is filled in
        var ok = true;
        $(inputSelector).each(function () {
            var fieldName = $(this).attr("name");

            // Don't worry about checkboxes (see below) or unnamed fields
            if (fieldName && $(this).attr("type") != "checkbox" ) {
                if (!engine.isAnswered($(this))) {
                    ok = false;
                    debug(fieldName + " not answered");
                }
            }
        });
        
        // data-required-checkbox-group: a group of checkboxes in which at least one must be ticked
        $(engine.groupSel(engine.currentGroupNum) + " *[data-required-checkbox-group='true']:visible").each(function() {
            if ($(this).find("input[type='checkbox']:checked").length == 0){
                ok = false;
            }
        });
        
        if (!ok) {
            // Don't display error on auto-next (ie. when they answer last question in group)
            if (!automatic) {
            	$('#answerAllMessage').show('slow');
            	$('#answerAllMessage').css('visibility','visible');
            }
            return;
        }

        // Validation
        ok = true;
        $('#answerAllMessage').hide();
        $('#answerAllMessage').css('visibility','hidden');
        $(inputSelector).each(function () {
            if (!engine.validator.element($(this)))
                ok = false;
        });
        if (!ok)
            return;

        // Have their answers made them ineligible?
        var ineligible = false;
        $(engine.groupSel(engine.currentGroupNum) + " .question").each(function () {
            var cond = $(this).attr("data-ineligible");
            if (cond) {
                if (engine.evaluate(cond)) {
                    ineligible = true;
                }
            }
        });
        if (ineligible) {
            engine.finish(true);
            return;
        }

        // hide all help text, change help toggle message & Display the next group of questions
        $('.help').each(function(){        	
        	if ($(this).is(':visible')){
        		$(this).data("wasVisible","true");
        		$(this).hide();
        	}        	
        });
       
        $('.helpButton').each(function(){   	
        	if ($(this).html() == 'Hide help text'){
	        	$(this).data("wasVisible","true");
	        	$(this).html($(this).data("helpText"));
        	}
        });
        
        engine.changeGroup(1);
        return false;
    },
    
    /** They've just hit Next in the last group, or they've been kicked out early */
    finish: function(ineligible) {
        engine.setProgressBarToFinished();
        engine.onFinished(ineligible);        
    },
    
    /**
     * Move forward or back a group. Groups whose visibility preconditions are not met are skipped.
     *
     * @param direction -1 = back, 1 = forwards, 0 = display whatever engine.currentGroupNum is
     */
    changeGroup:function (direction) {
        engine.disableCurrentGroup();

        // Move to the next or previous group. If the group or all its questions
        // are to be hidden, continue to the next one.
        var newGroupNum = engine.currentGroupNum;
        var keepGoing = true;
        while (keepGoing) {
            newGroupNum += direction;
            var group = $(engine.groupSel(newGroupNum));

            // Have we reached the end?
            if (group.length == 0) {
                engine.finish(false);
                return;
            }

            if (engine.shouldShow(group)) {
                if (engine.showOrHideElementsInGroup(group) > 0)
                    keepGoing = false;
            }
            else {
                // Through use of the back button, we might now have an answer to a question that
                // no longer applies. Clear it to save confusion. (This also happens in the
                // question-hiding code.)
                engine.clearAllControlsIn(group);
            }
        }

        // Enable controls in the new group
        $(engine.groupSel(newGroupNum) + " :input").each(function () {
            $(this).removeAttr("disabled");
            $(this).removeClass("dontRead");
        });

        // Highlight the new group
        $(engine.groupSel(newGroupNum)).addClass("current");

        // Show or hide back button
        if (newGroupNum == 0)
            $("#backButton").hide();
        else
            $("#backButton").show();

        /*
         // Reveal the group (if it's not already displayed) and scroll the window so it's
         // fully visible if necessary.
         $(grp(newGroupNum)).slideDown(engine.SLIDE_TIME, function() {
         if (!scrollToVisible($(grp(newGroupNum)).offset().top))
         scrollToVisible($("#backButton").offset().top + $("#backButton").height());
         });
         */

        // Hide all question groups after this one
        $(engine.groupSel(newGroupNum)).nextAll(".group").hide(/*engine.SLIDE_TIME*/);

        engine.revealAndScroll($(engine.groupSel(newGroupNum)));
        engine.currentGroupNum = newGroupNum;
        
        engine.afterVisibilityChanged($(engine.groupSel(newGroupNum)));

        // Focus on the first field in the group
        var firstInput = $(engine.groupSel(newGroupNum) + " :input:visible:first");
        firstInput.focus();
        firstInput.select();

        engine.updateProgressBar();
    },

    /** Reveal the question group and scroll the page so the group is centered vertically (if it fits)*/
    revealAndScroll:function (elt) {
        elt.show(/*engine.SLIDE_TIME*/);

        var y = elt.offset().top - engine.groupScrollYPosition;
        if (y < 0)
            y = 0;
        
        var bb = $("#bottomBuffer");
        if (bb.length) {
            var h = $(window).height() - (bb.offset().top - y);
            if (h < 0)
                h = 0;
            bb.height(h);
            //alert("y: " + y + " t: " + bb.offset().top + ", h: " + $(window).height());
        }

        $('html,body').animate({scrollTop:y}, {duration:engine.SLIDE_TIME, queue:false});

        /*
         // This code scrolls the page so the group is centered vertically (if it fits).
         // Might be userful. Would need to be modified to take account of the fixed position header.
         //
         var y = elt.offset().top - (window.innerHeight - elt.height()) / 2;
         // It's one of the first questions - scroll to top of page if not there already
         if (y < 0)
         y = 0;
         // Group taller than window - scroll to top of group
         if (y > elt.offset().top)
         y = elt.offset().top;
         $('html,body').animate({scrollTop: y}, {duration: engine.SLIDE_TIME, queue: false});
         */
    },

    /**
     * Shows or hides elements in the specified group according to their visibility preconditions -
     * usually it's questions that have preconditions but it may be other elements too.
     * 
     * @param group - jquery element
     * @return {Number} the number of visible questions in the group
     */
    showOrHideElementsInGroup:function(group) {
        // Show/hide non-question elements with visibility conditions
        group.find("[data-visible]").each(function() {
            if (!$(this).hasClass("question"))
                engine.applyVisibility($(this));
        });

        var visible = 0;
        group.find(".question").each(function () {
            if (engine.shouldShow($(this))) {
                if (group.is(':visible'))
                    $(this).slideDown(engine.SLIDE_TIME);
                else
                    $(this).show();
                visible++;
            }
            else {
                // Through use of the back button, we might now have an answer to a question that
                // no longer applies. Clear it to save confusion. (This also happens in the
                // group-hiding code.)
                engine.clearAllControlsIn($(this));
                $(this).hide();
            }
        });

        engine.afterVisibilityChanged(group);

        return visible;
    },
    
    afterVisibilityChanged: function(group) {
        // Some css help
        $(".lastVisibleQuestion").removeClass("lastVisibleQuestion");
        var last = group.find(".question:visible:last");
        last.addClass("lastVisibleQuestion");
    },

    /** Unhighlight the current group and disable its controls */
    disableCurrentGroup:function () {
        $(engine.groupSel(engine.currentGroupNum)).removeClass("current");
        $(engine.groupSel(engine.currentGroupNum)).addClass("dontRead");

        $(engine.groupSel(engine.currentGroupNum) + " :input").each(function () {
            $(this).attr("disabled", "disabled");    
        });
    },
    

    restart:function(){
    	
    	window.location.reload();
    	
    },


// ------------------- Nuts and bolts --------------------

    /**
     * Loads html page "fragments" from a list of urls into the supplied element.
     * Existing element content is removed. Loading is asynchronous - supply an
     * onFinished callback if you want to do somethig once loading is complete.
     *
     * @param intoElement  - jQuery element to load content into
     * @param fragmentUrls -  Array of urls
     * @param onFinished - callback when finished
     */
    loadPageFragmentsAndReplaceVariables:function (intoElement, fragmentUrls, onFinished) {
        intoElement.html("");
        var fetch = function () {
            if (fragmentUrls.length) {
                var url = fragmentUrls.shift();

                // avoid caching
                url += (url.match(/\?/) ? "&" : "?") + "dummy=" + $.now();

                debug("fetching " + url);
                var newbox = $("<div class='pageFragment'></div>");
                newbox.appendTo(intoElement);
                newbox.load(url, null, fetch);
            }
            else {
                intoElement.html(engine.replaceVariablesInText(intoElement.html()));
                if (onFinished)
                    onFinished();
            }
        };
        fetch();
    },

    /**
     * Resolve all $something variable references in the supplied text.
     *
     * @param text - text to process
     * @return processed text
     */
    replaceVariablesInText:function (text) {
    	if (null==text){return "";}
        return text.replace(/(\$[a-z,A-Z]+)\b/g, engine.evaluate);
    },

    /**
     * Shows or hides the element according to its precondition. If it doesn't have a
     * precondition, it's shown.
     * @param element - a jquery element
     * @return {Boolean} true if it's shown
     */
    shouldShow:function (element) {
        var cond = element.attr("data-visible");
        return !cond || engine.evaluate(cond);
    },
    
    applyVisibilityToChildren: function(element) {
        element.find("*[data-visible]").each(function () {
            engine.applyVisibility($(this));
        });
    },
    
    applyVisibility: function(elt) {
        if (engine.shouldShow(elt)) {
            elt.show();
        }
        else {
            elt.hide();
            engine.clearAllControlsIn(elt);
        }
    },

    /**
     * Evaluate a JavaScript-style expression. Variables references as $something will
     * be resolved using processVariables (see below).
     *
     * Note that because non-answered numeric questions evaluate to 0, calculations using
     * non-answered questions are ok.
     *
     * @param expression - eg. "$age > 25 && $single" or "$applicantIncome + $partnerIncome"
     * @return {*} the result of evaluating the expression
     */
    evaluate:function (expression) {
        debugIf(debugConditions, "expression: " + expression);
        var cond2 = engine.processVariables(expression);
        debugIf(debugConditions, "processed expression: " + cond2);
        eval("window.evaluationResult = " + cond2);
        debugIf(debugConditions, " -> " + window.evaluationResult);
        return window.evaluationResult;
    },


    evalMap:function (map, description) {
    	for (var exp in map){
    		if (engine.evaluate(exp)){
                debug(description + ": " + map[exp]);
    			return map[exp];
    		}
    	}
    	debug("evalMap - no match found for " + description);
    	return undefined;
    },

    /**
     * Converts a condition string to a JS string we can eval, by expanding $variables to
     * either getAnswer calls or rule definitions as appropriate. Expansion is recursive.
     * @param expression  eg. "$age > 25 && $single"
     * @return JavaScript code
     */
    processVariables:function (expression) {
        return expression.replace(/\$(\w+)/g, function (s) {
            var result;
            var name = s.substring(1);
            if (engine.definitions[name] !== undefined) {
                if (jQuery.type(engine.definitions[name]) == "string")
                    result = "(" + engine.processVariables(engine.definitions[name]) + ")";
                else
                    result = "(" + engine.definitions[name] + ")";
            }
            else {
                result = "engine.getAnswer('" + name + "')";
            }
            //debug("'" + s + "' => '" + result + "'");
            return result;
        });
    },

    /**
     * Get the value they entered or selected for the specified field.
     * If the question hasn't been answered, undefined is returned.
     *
     * String values are trimmed and blanks are returned as undefined.
     *
     * Numbers (class="number" - as also used by jQuery validation) are
     * returned as actual numbers if valid,
     * a string if not valid and 0 if blank. (The latter is important for
     * calculations involving questions which have not needed to be answered.)
     *
     * For radio buttons and checkboxes, "true" and "false" are converted to their
     * actual boolean values.
     *
     * @param fieldName - eg. age
     * @return {*} the value of the field
     */
    getAnswer:function (fieldName) {
        var element = $(":input[name=" + fieldName + "]");
        var val = engine.getAnswerAsText(fieldName);

        if (element.attr("type") == "radio") {
            if (val == "true")
                val = true;
            else if (val == "false") 
                val = false;
        }
        
        else if (element.attr("type") == "checkbox") {
            if (val == "true")
                val = true;
            else 
                val = false;
        }

        else if (element.hasClass("number")) {
            if (val === undefined) {
                val = 0;
            }
            else if (!isNaN(Number(val))) {
                val = Number(val);
            }
        }
        
        else if (element.hasClass("digit")) {
            if (val === undefined) {
                val = 0;
            }
            else if (!isNaN(Number(val))) {
                val = Number(val);
            }
        }

        else if (element.hasClass("currency")) {
            if (val === undefined) {
                val = 0;
            }
            else {
                var v2 = val;

                // Remove leading $ sign
                v2 = v2.replace(/^\$/, "");
                
                // Remove commas
                v2 = v2.replace(/,/g, "");

                if (!isNaN(Number(v2))) {
                    val = Number(v2);
                }
            }
        }

        return val;
    },

    /**
     * Returns the answer they've entered, without converting booleans
     * or numbers. Usually you'll want getAnswer() instead.
     *
     * Does convert blanks to undefined though.
     *
     * @param fieldName
     * @return {*}
     */
    getAnswerAsText:function (fieldName) {
        var element = $(":input[name=" + fieldName + "]");
        if (element.length == 0) {
            throw "No such field name (have you forgotten to define a rule?): " + fieldName;
        }
        return engine.getInputValueAsText(element);
    },

    getInputValueAsText:function (element) {
        var val;

        // Radio button - look for a checked element with the same name
        if (element.attr("type") == "radio") {
            var checkedElt = $("input[name=" + element.attr("name") + "]:checked");
            val = checkedElt.val();
        }

        // Checkboxes - note we assume each has its own name - we don't handle multiple checkboxes
        // with the same name
        else if (element.attr("type") == "checkbox") {
            val = element.attr("checked")? element.val() : undefined;
        }

        // Text fields and selects
        else {
            val = element.val();
            if (val !== undefined) {
                val = $.trim(val);
                if (val === "")
                    val = undefined;
            }
        }
        return val;
    },

    /**
     * @param input - a jQuery element
     * @return {Boolean} whether an answer has been provided for this field
     */
    isAnswered:function (input) {
        return engine.getInputValueAsText(input) !== undefined;
    },

    /**
     * Clear all controls within the specified element
     * @param elt - jQuery element
     */
    clearAllControlsIn:function (elt) {
        elt.find(":text").val("");
        elt.find(":radio").attr("checked", false);
        elt.find(":checkbox").attr("checked", false);

        // select the first option in every select - we assume this is the "unselected" option
        elt.find("select :nth-child(1)").attr("selected", "selected");

        // remove any validation error messages
        elt.find("label.error").remove();

        // Custom client code
        engine.onControlsClearedInElement(elt);
    },

    /**
     * Update the progress bar to reflect how far through we think they are.
     *
     * Note we assume the progress bar goes from 0 to 100.
     */
    updateProgressBar:function () {
        var progressBar = $("#progress");
        if (progressBar.length) {
            /*
             The calculation is simply the current group compared to the total number of groups.
             (We used to do something more complicated based on the number of questions we thought 
             they had left, but progress went backwards in some circumstances.)
             Note with this algorithm they often never reach 100%, so the call to setProgressBarToFinished()
             is important.
             */
            var result = Math.max(5, Math.round((engine.currentGroupNum + 1) * 100 / $(".group").length));
            progressBar.progressbar("option", "value", result);
        }
    },
    
    setProgressBarToFinished: function() {
        var progressBar = $("#progress");
        if (progressBar.length) {
            progressBar.progressbar("option", "value", 100);
        }
    },

    /**
     * Scroll the window so that the specified y coordinate is visible. If scrolling is performed,
     * y ends up 50 pixels away from the top or bottom of the window.
     *
     * @param y coordinate
     * @return {Boolean} whether scrolling was necessary
     */
    scrollToVisible:function (y) {
        var newTop = 0;
        if (y < $(window).scrollTop()) {
            newTop = y - 50;
        }
        else if (y > $(window).scrollTop() + window.innerHeight) {
            newTop = y - window.innerHeight + 50;
        }
        else {
            newTop = 0;
        }

        if (newTop != 0) {
            $('html,body').animate({scrollTop:newTop}, engine.SLIDE_TIME);
            return true;
        }
        else
            return false;
    },

    /**
     * @param groupNum group number (starting at 0)
     * @return {String} jQuery selector for selecting the specified group
     */
    groupSel:function (groupNum) {
        return ".group:eq(" + groupNum + ")";
    },

    /**
     * A number with
     * - optional leading $
     * - optional cents (ie 2 decimal places)
     * - options commas (see validateIntegerWithOptionalCommas() below)
     * 
     * The string is trimmed before validation. Blanks are valid.
     * 
     * @param str
     * @return {Boolean}
     */
    validateCurrency: function (str) {
        str = $.trim(str);
        
        if (str == "")
            return true;
        
        // remove cents if present
        str = str.replace(/\.\d\d$/, "");
        
        // remove leading $ if present
        str = str.replace(/^\$/, "");
        
        return engine.validateIntegerWithOptionalCommas(str);
    },

    /**
     * An integer with optional commas. If commas are present at all, they must
     * all be present and in the correct places.
     * 
     * 1000 and 100000 and 1 are valid
     * 1,000 and 100,000 are valid
     * 10,00 and 10,000000 are not valid
     * 
     * The string is trimmed before validation. Blanks are valid.
     * 
     * @param str
     * @return {Boolean}
     */
    validateIntegerWithOptionalCommas: function(str) {
        str = $.trim(str);

        if (/,/.test(str)) {
            return /^\d{1,3}(,\d{3})*$/.test(str);
        }
        
        // No commas - must be digits (or blank)
        else {
            return /^\d*$/.test(str);
        }
    }
    
};

/* ----------- Date extensions ------------ */

/**
 * Validate that a date is in the format "31/1/1970" or "31 Jan 1970"
 * @param str
 * @return {Boolean}
 */
Date.validateNzDate = function(str) {
    return Date.parseNzDate(str) != undefined;
};

/**
 * Parse a date in the format "31/1/1970" or "31 Jan 1970".
 * @param str Date string
 * @return Date (not millis!), or undefined if the string is invalid
 */
Date.parseNzDate = function(str) {
    var date = undefined;

    // parseDate is lenient about the number of digits in a year. We don't want that.
    if (str != undefined && str.match(/[/ ]\d\d\d\d$/)) {

        // 31/1/1970
        date = Date.parseWithFormat(str, "d/m/yy");

        // 31 Jan 1970
        if (date == undefined)
            date = Date.parseWithFormat(str, "d M yy");
    }
    return date;
};

/**
 * Parses a date in the specified format. Currently implemented using JQuery UI's $.datepicker.parseDate().
 * Note it is lenient about the number of digits in a year.
 * 
 * @param dateStr
 * @param format
 * @return Date (not millis!) or undefined if the date string (or format string) is invalid
 */
Date.parseWithFormat = function(dateStr, format) {
    try {
        return $.datepicker.parseDate(format, dateStr);
    }
    catch (ex) {
        return undefined;
    }
};

/**
 * The number of years otherDate is after this date. Time of day is ignored.
 * 
 * @param otherDate
 * @return years - possibly fractional, possibly negative
 */
Date.prototype.yearsBefore = function(otherDate) {
    // We deal with one component at a time - this ensures the number we produce
    // is intuitively correct, producing a better result than simply calculating
    // the different in millis and dividing by the appropriate number.
    var years = otherDate.getFullYear() - this.getFullYear();
    var copy = new Date(this.getTime());
    copy.setFullYear(otherDate.getFullYear());
    years += (otherDate.getMonth() - copy.getMonth()) / 12;
    copy.setMonth(otherDate.getMonth());
    years += (otherDate.getDate() - copy.getDate()) / 365.4;
    return years;
};

